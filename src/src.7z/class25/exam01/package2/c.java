package class25.exam01.package2;

import class25.exam01.package1.B;

public class c {
	//필드 선언
	//A a; //x A클래스 접근 불가
	B b;   //o

}
