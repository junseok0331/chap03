package class25.exam01.package1;



public class B {
	//필드 선언
	A a;    //o A클래스 접근 가능

}
