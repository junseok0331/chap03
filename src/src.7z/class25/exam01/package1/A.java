package class25.exam01.package1;

//클래스의 default 접근제한

class A {   //public 쓰면 c에서 사용할 수 있음.

}
