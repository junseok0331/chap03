package class24.exam01.hyundai;

public class Engine {

	public Engine() {
		System.out.println("여기는 현대자동차 Engin 생성자");

	}
}
