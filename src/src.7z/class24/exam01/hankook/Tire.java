package class24.exam01.hankook;

public class Tire {
	
	public Tire() {
		System.out.println("여기는 hankook 패키지의 Tire 클래스 생성자");
		
	}

}
