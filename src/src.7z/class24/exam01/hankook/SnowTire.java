package class24.exam01.hankook;

public class SnowTire {
	public SnowTire() {
		System.out.println("여기는 한국타이어의 SnowTire 클래스 생성자");
	}

}
