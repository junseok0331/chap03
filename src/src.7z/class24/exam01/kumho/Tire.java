package class24.exam01.kumho;

public class Tire {

	public Tire() {
		System.out.println("여기는 kumho 패키지 Tire 클래스 생성자");
	}

}
