package class24.exam01.kumho;

public class BigWidthTire {

	public BigWidthTire() {
		System.out.println("여기는 금호타이어 BigWidthTire 클래스 생성자");

	}

}
